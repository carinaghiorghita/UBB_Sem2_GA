class ExistError(Exception):
    pass