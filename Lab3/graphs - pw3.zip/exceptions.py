class ExistError(Exception):
    pass

class NegativeCycleError(Exception):
    pass